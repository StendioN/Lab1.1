package ua.kpi.comsys.io8118.ui.movieList

import com.fasterxml.jackson.annotation.JsonProperty

class SearchContainer {
    @JsonProperty("Search")
    var search: MutableList<Search> = ArrayList()
    override fun toString(): String {
        return search.toString()
    }
}